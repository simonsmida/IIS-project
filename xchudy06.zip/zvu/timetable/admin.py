from django.contrib import admin

from shelter.models import Timetable

admin.site.register(Timetable)