from django.contrib import admin

from shelter.models import Reservation

admin.site.register(Reservation)