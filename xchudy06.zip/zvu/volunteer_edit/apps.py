from django.apps import AppConfig


class Volunteer_editConfig(AppConfig):
    name = 'volunteer_edit'
