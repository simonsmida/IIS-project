from django.contrib import admin

# from shelter.models import Volunteer

# admin.site.register(Volunteer)