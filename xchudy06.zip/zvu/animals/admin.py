from django.contrib import admin

from shelter.models import Animal

admin.site.register(Animal)