from django.apps import AppConfig


class VetrequestConfig(AppConfig):
    name = 'vetrequest'
