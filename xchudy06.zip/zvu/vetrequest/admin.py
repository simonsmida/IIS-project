from django.contrib import admin

from shelter.models import Vetrequest

admin.site.register(Vetrequest)