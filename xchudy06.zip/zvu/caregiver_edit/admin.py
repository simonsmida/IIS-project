from django.contrib import admin

# from shelter.models import Caregiver

# admin.site.register(Caregiver)