from django.apps import AppConfig


class Caregiver_editConfig(AppConfig):
    name = 'caregiver_edit'
