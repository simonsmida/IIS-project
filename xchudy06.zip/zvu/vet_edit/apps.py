from django.apps import AppConfig


class Vet_editConfig(AppConfig):
    name = 'vet_edit'
