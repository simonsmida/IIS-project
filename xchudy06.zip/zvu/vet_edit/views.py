from django.shortcuts import render, get_object_or_404, redirect
from .forms import VetForm, VetChangeForm
from django.contrib.auth.models import User
from django.contrib.auth.models import Group
from django.contrib.auth.decorators import login_required, permission_required


@login_required(login_url="login")
@permission_required("auth.add_user", login_url="/login", raise_exception=True)
def vet_create_view(request):
    my_group = Group.objects.get(name="vet")
    form = VetForm(request.POST or None)
    if form.is_valid():
        user = form.save()
        my_group.user_set.add(user)
        form = VetForm()
        return redirect('../')
    context = {
        'form': form
    }
    return render(request, "vet_edit/vet_create.html", context)


@login_required(login_url="login")
@permission_required("auth.change_user", login_url="/login", raise_exception=True)
def vet_update_view(request, id=id):
    obj = get_object_or_404(User, id=id)
    form = VetChangeForm(request.POST or None, instance=obj)
    if form.is_valid():
        form.save()
        return redirect('../')
    context = {
        'form': form
    }
    return render(request, "vet_edit/vet_create.html", context)


@login_required(login_url="login")
@permission_required("auth.view_user", login_url="/login", raise_exception=True)
def vet_list_view(request):
    queryset = User.objects.filter(groups__name='vet') # list of objects
    context = {
        "object_list": queryset
    }
    return render(request, "vet_edit/vet_list.html", context)


@login_required(login_url="login")
@permission_required("auth.view_user", login_url="/login", raise_exception=True)
def vet_detail_view(request, id):
    obj = get_object_or_404(User, id=id)
    context = {
        "object": obj
    }
    return render(request, "vet_edit/vet_detail.html", context)

@login_required(login_url="login")
@permission_required("auth.delete_user", login_url="/login", raise_exception=True)
def vet_delete_view(request, id):
    obj = get_object_or_404(User, id=id)
    if request.method == "POST":
        obj.delete()
        return redirect('../../')
    context = {
        "object": obj
    }
    return render(request, "vet_edit/vet_delete.html", context)
